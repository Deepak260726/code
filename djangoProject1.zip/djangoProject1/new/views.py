import random

import requests
from django.core.management import utils
from django.shortcuts import render

# Create your views here.
from rest_framework import viewsets
from rest_framework.authtoken.models import Token
from rest_framework.response import Response
from rest_framework.utils import json
from rest_framework.views import APIView

from new.models import Account, Destination
from new.serializer import AccountSerializer, DestinationSerializer


class Accountviewset(APIView):

    def post(self, request, *args, **kwargs):
        email_id = request.data["email_id"]
        account_name = request.data["account_name"]
        website = request.data["website"]
        res = Account.objects.filter().last()
        account_id = random.randint(0,999)
        token =  utils.get_random_secret_key()
        data = Account.objects.create(email_id=email_id,account_name=account_name,account_id=account_id,token=token,website=website)
        data.save()
        return Response({"Message":"account created successfully"},201)


class accountget(APIView):

    def get(self,request):
        account_id = request.GET.get("account_id")
        mode = request.GET.get("mode")
        if mode == "0":
            result = Account.objects.all()
        else:
            result = Account.objects.filter(account_id=account_id)
        serializer = AccountSerializer(result, many=True)
        print(serializer)
        return Response(serializer.data)

class updateaccount(APIView):

    def put(self,request):
        email_id = request.data["email_id"]
        account_name = request.data["account_name"]
        website = request.data["website"]
        account_id = request.GET.get("account_id")
        data = Account.objects.filter(account_id=account_id)
        data.update(email_id=email_id,account_name=account_name,website=website)
        return Response({"Message" : "account updated successfully"},200)

class deleteaccount(APIView):

    def delete(self,request):
        account_id = request.GET.get("account_id")
        data = Account.objects.filter(account_id=account_id)
        data.delete()
        return Response({"Message" : "account deleted successfully"},200)



class createdestination(APIView):
    def post(self,request):
        url = request.data["url"]
        method = request.data["method"]
        headers = request.data["headers"]
        account_id = request.data["account_id"]
        data = Destination.objects.create(url=url, http_method=method, headers=headers, account=account_id)
        data.save()
        return Response({"Message": "destination created successfully"}, 201)


class destinationget(APIView):

    def get(self,request):
        account_id = request.GET.get("account_id")
        mode = request.GET.get("mode")
        if mode == "0":
            result = Destination.objects.all()
        else:
            result = Destination.objects.filter(account_id=account_id)
        serializer = DestinationSerializer(result, many=True)
        print(serializer)
        return Response(serializer.data)

class update_destination(APIView):

    def put(self,request):
        url = request.data["url"]
        method = request.data["method"]
        headers = request.data["headers"]
        account_id = request.GET.get("account_id")
        data = Destination.objects.filter(account_id=account_id)
        data.update(url=url,http_method=method,headers=headers)
        return Response({"Message" : "Destination updated successfully"},200)

class deletedestination(APIView):

    def delete(self,request):
        account_id = request.GET.get("account_id")
        data = Destination.objects.filter(account_id=account_id)
        data.delete()
        return Response({"Message" : "Destination deleted successfully"},200)

class recievingviewset(APIView):

    def post(self,request):
        email_id = request.data["email_id"]
        account_name = request.data["account_name"]
        website = request.data["website"]
        mode = request.data["mode"]
        res = Account.objects.filter().last()
        account_id = request.GET.get("account_id")
        token = utils.get_random_secret_key()
        res = Destination.objects.filter(account=account_id).last()
        url = res.url
        http_method = res.http_method
        headers = res.headers
        payload = {"email_id":email_id,"account_name":account_name,"website":website,"token":token}
        if http_method == "POST":
            res = requests.post(url, data = payload)
            if res.status_code == 201:
                return Response({"Message" : "created successfully "},200)
        elif http_method == "GET":
            url = url + "?" + "account_id" + '='+ account_id + "&" + "mode" + "=" + mode
            res = requests.get(url)
            return Response(res.json(),200)
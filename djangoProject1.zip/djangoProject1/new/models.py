from django.db import models

# Create your models here.

class Account(models.Model):
    email_id = models.CharField(max_length=200)
    account_id = models.CharField(max_length=200)
    account_name = models.CharField(max_length = 200)
    token = models.CharField(max_length=200)
    website = models.CharField(max_length=50)

class Destination(models.Model):
     account = models.CharField(max_length=50)
     url = models.CharField(max_length=200)
     http_method = models.CharField(max_length=200)
     headers = models.JSONField()

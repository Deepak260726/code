from rest_framework import serializers

from new.models import Account, Destination


class AccountSerializer(serializers.ModelSerializer):
    class Meta:
        model = Account
        fields = ["email_id","account_name","website","token"]

class DestinationSerializer(serializers.ModelSerializer):
    class Meta:
        model = Destination
        fields = ["url","http_method","headers"]
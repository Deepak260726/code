
from django.urls import path

from new import views




urlpatterns = [
    path('account/', views.Accountviewset.as_view(), name='account'),
    path('getaccount', views.accountget.as_view(), name='account'),
    path('updateaccount/',views.updateaccount.as_view(),name='account'),
    path('deleteaccount',views.deleteaccount.as_view(),name='account'),
    path('destination/', views.createdestination.as_view(), name='account'),
    path('getdestination', views.destinationget.as_view(), name='account'),
    path('updatedestination/', views.update_destination.as_view(), name='account'),
    path('deletedestination', views.deletedestination.as_view(), name='account'),
    path('server/incoming_data/', views.recievingviewset.as_view(), name='account'),
]
